import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class SongStat {
  int ms;
  int plays;
  final String title;
  final String artist;
  SongStat({required this.title, required this.artist, this.ms = 0, this.plays = 0});
}

/// Listening statistics. Time is measured with the wall clock only while audio
/// is really playing, and split at midnight so every day is exact.
class StatsService extends ChangeNotifier {
  SharedPreferences? _p;

  final Map<String, int> daily = <String, int>{}; // 'yyyy-MM-dd' -> milliseconds
  final Map<String, SongStat> songs = <String, SongStat>{};

  bool _active = false;
  DateTime? _mark;
  Song? _cur;
  int _curAccum = 0;
  bool _counted = false;
  Timer? _timer;
  int _ticks = 0;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    try {
      final d = p.getString('stats_daily');
      if (d != null) {
        (jsonDecode(d) as Map<String, dynamic>).forEach((k, v) {
          daily[k] = (v as num).toInt();
        });
      }
      final s = p.getString('stats_songs');
      if (s != null) {
        (jsonDecode(s) as Map<String, dynamic>).forEach((k, v) {
          final l = v as List<dynamic>;
          songs[k] = SongStat(
            ms: (l[0] as num).toInt(),
            plays: (l[1] as num).toInt(),
            title: l[2].toString(),
            artist: l[3].toString(),
          );
        });
      }
    } catch (_) {}
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_active) {
        _flush();
        _ticks++;
        if (_ticks % 6 == 0) _save();
        notifyListeners();
      }
    });
  }

  // ------------------------------------------------------------- recording

  void setActive(bool active) {
    if (active == _active) return;
    _flush();
    _active = active;
    _mark = active ? DateTime.now() : null;
    if (!active) _save();
    notifyListeners();
  }

  void setSong(Song? s) {
    if (_cur?.id == s?.id) return;
    _flush();
    _cur = s;
    _curAccum = 0;
    _counted = false;
  }

  static String _key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _flush() {
    final mark = _mark;
    if (!_active || mark == null) return;
    final now = DateTime.now();
    if (!now.isAfter(mark)) {
      _mark = now;
      return;
    }
    var from = mark;
    while (true) {
      final midnight = DateTime(from.year, from.month, from.day + 1);
      if (now.isBefore(midnight)) {
        _addDaily(from, now.difference(from).inMilliseconds);
        break;
      }
      _addDaily(from, midnight.difference(from).inMilliseconds);
      from = midnight;
    }
    final total = now.difference(mark).inMilliseconds;
    final cur = _cur;
    if (cur != null) {
      final st = songs.putIfAbsent(
          cur.key, () => SongStat(title: cur.title, artist: cur.artist));
      st.ms += total;
      _curAccum += total;
      final threshold = math.max(5000, math.min(30000, cur.durationMs ~/ 2));
      if (!_counted && _curAccum >= threshold) {
        st.plays += 1;
        _counted = true;
      }
    }
    _mark = now;
  }

  void _addDaily(DateTime day, int ms) {
    if (ms <= 0) return;
    final k = _key(day);
    daily[k] = (daily[k] ?? 0) + ms;
  }

  void _save() {
    final p = _p;
    if (p == null) return;
    p.setString('stats_daily', jsonEncode(daily));
    p.setString(
      'stats_songs',
      jsonEncode(songs.map((k, v) => MapEntry(k, <dynamic>[v.ms, v.plays, v.title, v.artist]))),
    );
  }

  Future<void> reset() async {
    daily.clear();
    songs.clear();
    _curAccum = 0;
    _counted = false;
    if (_active) _mark = DateTime.now();
    _save();
    notifyListeners();
  }

  // --------------------------------------------------------------- queries

  DateTime get _today {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  int msOn(DateTime d) => daily[_key(d)] ?? 0;

  int get todayMs {
    _flush();
    return msOn(_today);
  }

  /// Oldest first, ending today.
  List<int> lastDaysMs(int n) {
    _flush();
    final t = _today;
    return List<int>.generate(n, (i) => msOn(DateTime(t.year, t.month, t.day - (n - 1 - i))));
  }

  List<DateTime> lastDays(int n) {
    final t = _today;
    return List<DateTime>.generate(n, (i) => DateTime(t.year, t.month, t.day - (n - 1 - i)));
  }

  int get last7Ms => lastDaysMs(7).fold<int>(0, (a, b) => a + b);

  int get yearMs {
    _flush();
    final prefix = '${_today.year}-';
    var total = 0;
    daily.forEach((k, v) {
      if (k.startsWith(prefix)) total += v;
    });
    return total;
  }

  /// Milliseconds per month (index 0 = January) of the current year.
  List<int> get monthlyMs {
    _flush();
    final year = _today.year;
    final out = List<int>.filled(12, 0);
    daily.forEach((k, v) {
      final parts = k.split('-');
      if (parts.length == 3 && int.tryParse(parts[0]) == year) {
        final m = int.tryParse(parts[1]) ?? 0;
        if (m >= 1 && m <= 12) out[m - 1] += v;
      }
    });
    return out;
  }

  int get allTimeMs {
    _flush();
    var total = 0;
    for (final v in daily.values) {
      total += v;
    }
    return total;
  }

  static int _daysBetween(DateTime a, DateTime b) {
    final ua = DateTime.utc(a.year, a.month, a.day);
    final ub = DateTime.utc(b.year, b.month, b.day);
    return ub.difference(ua).inDays;
  }

  /// Days since the first listening day of this year (at least 1).
  int get yearDaysCovered {
    final t = _today;
    DateTime? first;
    daily.forEach((k, v) {
      final parts = k.split('-');
      if (parts.length != 3 || v <= 0) return;
      final y = int.tryParse(parts[0]);
      if (y != t.year) return;
      final d = DateTime(y!, int.tryParse(parts[1]) ?? 1, int.tryParse(parts[2]) ?? 1);
      if (first == null || d.isBefore(first!)) first = d;
    });
    if (first == null) return 1;
    return math.max(1, _daysBetween(first!, t) + 1);
  }

  double get yearDailyAvgMs => yearMs / yearDaysCovered;

  double get yearWeeklyAvgMs => yearMs / math.max(1.0, yearDaysCovered / 7.0);

  double get weekDailyAvgMs => last7Ms / 7.0;

  /// Consecutive days (ending today, or yesterday if nothing yet today) with
  /// at least one minute of listening.
  int get streak {
    _flush();
    final t = _today;
    var day = msOn(t) >= 60000 ? t : DateTime(t.year, t.month, t.day - 1);
    var count = 0;
    while (msOn(day) >= 60000) {
      count++;
      day = DateTime(day.year, day.month, day.day - 1);
    }
    return count;
  }

  List<SongStat> topSongs(int n) {
    final list = songs.values.where((s) => s.ms > 0).toList();
    list.sort((a, b) => b.ms.compareTo(a.ms));
    return list.take(n).toList();
  }
}
