import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart' show PointerDeviceKind;

/// Brand colours & gradients (modern blue).
class AppColors {
  static const Color blue1 = Color(0xFF3B6BFF);
  static const Color blue2 = Color(0xFF22C7FF);
  static const Color accent = Color(0xFF3FA4FF);
  static const Color danger = Color(0xFFFF453A);

  static const LinearGradient primary = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [blue1, blue2],
  );

  static const LinearGradient soft = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0x553B6BFF), Color(0x5522C7FF)],
  );
}

/// Light / dark palette, interpolated smoothly when the theme changes.
class Palette extends ThemeExtension<Palette> {
  final Color bg;
  final Color surface;
  final Color surface2;
  final Color text;
  final Color subtext;
  final Color divider;
  final Color glass;
  final Color glassBorder;

  const Palette({
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.text,
    required this.subtext,
    required this.divider,
    required this.glass,
    required this.glassBorder,
  });

  static const Palette dark = Palette(
    bg: Color(0xFF000000),
    surface: Color(0xFF141416),
    surface2: Color(0xFF1F1F23),
    text: Color(0xFFFFFFFF),
    subtext: Color(0xFF8E8E93),
    divider: Color(0x1FFFFFFF),
    glass: Color(0xCC121214),
    glassBorder: Color(0x1FFFFFFF),
  );

  static const Palette light = Palette(
    bg: Color(0xFFFFFFFF),
    surface: Color(0xFFF2F2F7),
    surface2: Color(0xFFE6E6ED),
    text: Color(0xFF0B0B0F),
    subtext: Color(0xFF6C6C72),
    divider: Color(0x1A000000),
    glass: Color(0xCCFFFFFF),
    glassBorder: Color(0x14000000),
  );

  @override
  Palette copyWith({
    Color? bg,
    Color? surface,
    Color? surface2,
    Color? text,
    Color? subtext,
    Color? divider,
    Color? glass,
    Color? glassBorder,
  }) {
    return Palette(
      bg: bg ?? this.bg,
      surface: surface ?? this.surface,
      surface2: surface2 ?? this.surface2,
      text: text ?? this.text,
      subtext: subtext ?? this.subtext,
      divider: divider ?? this.divider,
      glass: glass ?? this.glass,
      glassBorder: glassBorder ?? this.glassBorder,
    );
  }

  @override
  Palette lerp(ThemeExtension<Palette>? other, double t) {
    if (other is! Palette) return this;
    return Palette(
      bg: Color.lerp(bg, other.bg, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surface2: Color.lerp(surface2, other.surface2, t)!,
      text: Color.lerp(text, other.text, t)!,
      subtext: Color.lerp(subtext, other.subtext, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      glass: Color.lerp(glass, other.glass, t)!,
      glassBorder: Color.lerp(glassBorder, other.glassBorder, t)!,
    );
  }
}

extension PaletteContext on BuildContext {
  Palette get pal => Theme.of(this).extension<Palette>() ?? Palette.dark;
}

/// Colour with a given opacity (avoids deprecated `withOpacity`).
Color alpha(Color c, double opacity) {
  final a = (opacity.clamp(0.0, 1.0) * 255).round();
  return c.withAlpha(a);
}

ThemeData buildTheme(bool dark) {
  final p = dark ? Palette.dark : Palette.light;
  final brightness = dark ? Brightness.dark : Brightness.light;
  final base = ThemeData(brightness: brightness, useMaterial3: true);
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue1,
    brightness: brightness,
  ).copyWith(
    primary: AppColors.blue1,
    secondary: AppColors.blue2,
    surface: p.bg,
    onSurface: p.text,
  );
  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    splashFactory: NoSplash.splashFactory,
    splashColor: Colors.transparent,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text),
    extensions: <ThemeExtension<dynamic>>[p],
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: <TargetPlatform, PageTransitionsBuilder>{
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      },
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: p.surface,
      elevation: 12,
      shadowColor: Colors.black54,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    textSelectionTheme: const TextSelectionThemeData(
      cursorColor: AppColors.accent,
      selectionHandleColor: AppColors.accent,
    ),
  );
}

/// iOS-like bouncing scroll everywhere.
class BouncyScrollBehavior extends MaterialScrollBehavior {
  const BouncyScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) =>
      const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());

  @override
  Widget buildOverscrollIndicator(
      BuildContext context, Widget child, ScrollableDetails details) {
    return child;
  }

  @override
  Set<PointerDeviceKind> get dragDevices => <PointerDeviceKind>{
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
      };
}
