import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

import 'globals.dart';
import 'models.dart';

/// Wraps just_audio: queue, shuffle / repeat, sleep timer.
class PlaybackService extends ChangeNotifier {
  late final AudioPlayer player;

  List<Song> queue = <Song>[];
  ConcatenatingAudioSource? _source;

  final ValueNotifier<Song?> currentSong = ValueNotifier<Song?>(null);

  /// Remaining time of a running sleep timer (null when off).
  final ValueNotifier<Duration?> sleepRemaining = ValueNotifier<Duration?>(null);

  /// True while "stop at the end of the current song" is armed.
  final ValueNotifier<bool> sleepAtSongEnd = ValueNotifier<bool>(false);

  Timer? _sleepTimer;
  DateTime? _sleepEnd;
  StreamSubscription<Duration>? _endSub;
  int _uid = 0;
  int _errorSkips = 0;

  Future<void> init() async {
    player = AudioPlayer();
    player.currentIndexStream.listen(_onIndex);
    player.playerStateStream.listen(_onState);
    player.shuffleModeEnabledStream.listen((_) => notifyListeners());
    player.loopModeStream.listen((_) => notifyListeners());
    player.playbackEventStream.listen((_) {}, onError: _onError);
  }

  bool get hasCurrent => currentSong.value != null;
  bool get shuffleOn => player.shuffleModeEnabled;
  LoopMode get loopMode => player.loopMode;
  bool get sleepActive =>
      sleepRemaining.value != null || sleepAtSongEnd.value;

  // ---------------------------------------------------------------- streams

  void _onIndex(int? i) {
    if (i == null || i < 0 || i >= queue.length) return;
    final song = queue[i];
    currentSong.value = song;
    stats.setSong(song);
    _errorSkips = 0;
    notifyListeners();
  }

  void _onState(PlayerState st) {
    final active = st.playing && st.processingState == ProcessingState.ready;
    stats.setActive(active);
    if (st.processingState == ProcessingState.ready) _errorSkips = 0;
  }

  void _onError(Object e, StackTrace st) {
    debugPrint('Playback error: $e');
    if (_errorSkips < 5 && player.hasNext) {
      _errorSkips++;
      player.seekToNext().then((_) => player.play());
    }
  }

  // ---------------------------------------------------------------- queueing

  AudioSource _toSource(Song s) {
    _uid++;
    return AudioSource.uri(
      s.uri,
      tag: MediaItem(
        id: '${s.id}_$_uid',
        title: s.title,
        artist: s.artist,
        album: s.album,
        duration: s.duration,
        artUri: musicLib.artUriFor(s),
      ),
    );
  }

  /// Replaces the queue with [songs] and starts playing [startIndex].
  /// [shuffle] = null keeps the current shuffle setting.
  Future<void> playSongs(List<Song> songs, int startIndex, {bool? shuffle}) async {
    if (songs.isEmpty) return;
    final index = startIndex.clamp(0, songs.length - 1).toInt();
    try {
      queue = List<Song>.of(songs);
      _source = ConcatenatingAudioSource(
        children: queue.map(_toSource).toList(),
      );
      await player.setAudioSource(
        _source!,
        initialIndex: index,
        initialPosition: Duration.zero,
      );
      if (shuffle != null) {
        if (shuffle) await player.shuffle();
        await player.setShuffleModeEnabled(shuffle);
      } else if (player.shuffleModeEnabled) {
        await player.shuffle();
      }
      currentSong.value = queue[index];
      stats.setSong(queue[index]);
      notifyListeners();
      player.play();
    } catch (e) {
      debugPrint('playSongs failed: $e');
    }
  }

  Future<void> shuffleAll(List<Song> songs) async {
    if (songs.isEmpty) return;
    final start = DateTime.now().millisecondsSinceEpoch % songs.length;
    await playSongs(songs, start, shuffle: true);
  }

  Future<void> playNext(Song s) async {
    final src = _source;
    if (src == null || queue.isEmpty) {
      await playSongs(<Song>[s], 0);
      return;
    }
    final at = ((player.currentIndex ?? -1) + 1).clamp(0, queue.length).toInt();
    queue.insert(at, s);
    await src.insert(at, _toSource(s));
    notifyListeners();
  }

  Future<void> addToQueue(Song s) async {
    final src = _source;
    if (src == null || queue.isEmpty) {
      await playSongs(<Song>[s], 0);
      return;
    }
    queue.add(s);
    await src.add(_toSource(s));
    notifyListeners();
  }

  Future<void> jumpTo(int index) async {
    if (index < 0 || index >= queue.length) return;
    await player.seek(Duration.zero, index: index);
    player.play();
  }

  // --------------------------------------------------------------- transport

  Future<void> togglePlay() async {
    if (!hasCurrent) return;
    if (player.playing) {
      await player.pause();
      return;
    }
    if (player.processingState == ProcessingState.completed) {
      await player.seek(Duration.zero, index: 0);
    }
    player.play();
  }

  Future<void> next() async {
    if (player.hasNext) {
      await player.seekToNext();
    } else if (queue.isNotEmpty) {
      await player.seek(Duration.zero, index: 0);
    }
  }

  Future<void> previous() async {
    if (player.position.inSeconds > 3 || !player.hasPrevious) {
      await player.seek(Duration.zero);
    } else {
      await player.seekToPrevious();
    }
  }

  Future<void> toggleShuffle() async {
    final enable = !player.shuffleModeEnabled;
    if (enable) await player.shuffle();
    await player.setShuffleModeEnabled(enable);
  }

  Future<void> cycleRepeat() async {
    final m = player.loopMode;
    await player.setLoopMode(m == LoopMode.off
        ? LoopMode.all
        : (m == LoopMode.all ? LoopMode.one : LoopMode.off));
  }

  // ------------------------------------------------------------ sleep timer

  void startSleepTimer(Duration d) {
    cancelSleep(restoreVolume: true);
    _sleepEnd = DateTime.now().add(d);
    sleepRemaining.value = d;
    _sleepTimer = Timer.periodic(const Duration(seconds: 1), (_) => _sleepTick());
    notifyListeners();
  }

  void startSleepAtSongEnd() {
    cancelSleep(restoreVolume: true);
    sleepAtSongEnd.value = true;
    _endSub = player.positionStream.listen((pos) {
      final d = player.duration;
      if (d == null || d.inMilliseconds < 1500) return;
      if (d.inMilliseconds - pos.inMilliseconds <= 350) {
        _finishAtSongEnd();
      }
    });
    notifyListeners();
  }

  void _sleepTick() {
    final end = _sleepEnd;
    if (end == null) return;
    final left = end.difference(DateTime.now());
    if (left <= Duration.zero) {
      _finishSleep();
      return;
    }
    sleepRemaining.value = left;
    // Gentle fade-out during the last 10 seconds.
    if (left.inMilliseconds < 10000) {
      player.setVolume((left.inMilliseconds / 10000.0).clamp(0.0, 1.0).toDouble());
    }
  }

  Future<void> _finishSleep() async {
    cancelSleep(restoreVolume: false);
    await player.pause();
    await player.setVolume(1.0);
    notifyListeners();
  }

  Future<void> _finishAtSongEnd() async {
    await _endSub?.cancel();
    _endSub = null;
    sleepAtSongEnd.value = false;
    await player.pause();
    final ni = player.nextIndex;
    if (player.loopMode != LoopMode.one && ni != null) {
      await player.seek(Duration.zero, index: ni);
    } else {
      await player.seek(Duration.zero);
    }
    notifyListeners();
  }

  void cancelSleep({bool restoreVolume = true}) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    _sleepEnd = null;
    _endSub?.cancel();
    _endSub = null;
    sleepRemaining.value = null;
    sleepAtSongEnd.value = false;
    if (restoreVolume) player.setVolume(1.0);
    notifyListeners();
  }
}
