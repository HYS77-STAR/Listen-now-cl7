import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'tabs.dart';

/// Back button + optional trailing widget + big title, shared by detail pages.
class DetailHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget? trailing;

  const DetailHeader({
    super.key,
    required this.title,
    required this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleIconButton(
                icon: Icons.arrow_back_ios_new_rounded,
                iconSize: 19,
                onTap: () => Navigator.of(context).maybePop(),
              ),
              const Spacer(),
              if (trailing != null) trailing!,
            ],
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Text(
              title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.9,
                height: 1.1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Text(
              subtitle,
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w600,
                color: p.subtext,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _totalTime(List<Song> songs) {
  final ms = songs.fold<int>(0, (a, s) => a + s.durationMs);
  final m = ms ~/ 60000;
  if (m < 60) return '$m min';
  final h = m ~/ 60;
  final rm = m % 60;
  return rm == 0 ? '$h hr' : '$h hr $rm min';
}

// =================================================================== FOLDER

class FolderScreen extends StatelessWidget {
  final String path;
  const FolderScreen({super.key, required this.path});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final scope = 'folder:$path';
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
          builder: (context, _) {
            final songs = appStore.sorted<Song>(
              scope: scope,
              items: musicLib.songsInFolder(path),
              keyOf: (s) => s.key,
              titleOf: (s) => s.title,
              dateOf: (s) => s.dateAdded,
            );
            return Column(
              children: [
                DetailHeader(
                  title: folderNameOf(path),
                  subtitle: songs.isEmpty
                      ? 'Empty'
                      : '${plural(songs.length, 'song')} · ${_totalTime(songs)}',
                  trailing: CircleIconButton(
                    icon: Icons.more_horiz_rounded,
                    onTap: () => showFolderMenu(context, path, popAfterHide: true),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: PlayShuffleRow(
                    enabled: songs.isNotEmpty,
                    onPlay: () => playback.playSongs(songs, 0, shuffle: false),
                    onShuffle: () => playback.shuffleAll(songs),
                  ),
                ),
                ListHeader(
                  count: 'Hold & drag to reorder',
                  sort: SortButton(
                    mode: appStore.sortModeOf(scope),
                    onChanged: (m) => appStore.chooseSort(
                        scope, m, songs.map((s) => s.key).toList()),
                  ),
                ),
                Expanded(
                  child: songs.isEmpty
                      ? const EmptyState(
                          icon: Icons.music_off_rounded,
                          title: 'No Songs',
                          subtitle: 'This folder does not contain any songs.',
                        )
                      : ReorderList<Song>(
                          items: songs,
                          keyOf: (s) => s.key,
                          itemExtent: 68,
                          onReordered: (list) => appStore.setManualOrder(
                              scope, list.map((s) => s.key).toList()),
                          itemBuilder: (context, s, i) => SongTile(
                            song: s,
                            onTap: () => playback.playSongs(songs, i),
                            onMore: () => showSongMenu(context, s),
                          ),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ================================================================= PLAYLIST

class PlaylistScreen extends StatelessWidget {
  final String playlistId;
  const PlaylistScreen({super.key, required this.playlistId});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final scope = 'playlist:$playlistId';
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
          builder: (context, _) {
            final pl = appStore.playlistById(playlistId);
            if (pl == null) {
              return Column(
                children: const [
                  DetailHeader(title: 'Playlist', subtitle: 'Not found'),
                ],
              );
            }
            final songs = appStore.sorted<Song>(
              scope: scope,
              items: musicLib.songsForIds(pl.songIds),
              keyOf: (s) => s.key,
              titleOf: (s) => s.title,
              dateOf: (s) => s.dateAdded,
              def: SortMode.manual,
              manualOverride: pl.songIds.map((e) => '$e').toList(),
            );
            return Column(
              children: [
                DetailHeader(
                  title: pl.name,
                  subtitle: songs.isEmpty
                      ? 'Empty playlist'
                      : '${plural(songs.length, 'song')} · ${_totalTime(songs)}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircleIconButton(
                        icon: Icons.add_rounded,
                        filled: true,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => SongPickerScreen(playlistId: pl.id),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      CircleIconButton(
                        icon: Icons.more_horiz_rounded,
                        onTap: () => showActionSheet(
                          context,
                          header: SheetHeader(
                            leading: PlaylistCover(songs: songs),
                            title: pl.name,
                            subtitle: plural(songs.length, 'song'),
                          ),
                          actions: [
                            SheetAction(
                              icon: Icons.edit_rounded,
                              label: 'Rename',
                              onTap: () => renamePlaylistFlow(context, pl),
                            ),
                            SheetAction(
                              icon: Icons.delete_outline_rounded,
                              label: 'Delete Playlist',
                              destructive: true,
                              onTap: () async {
                                final ok = await deletePlaylistFlow(context, pl);
                                if (ok && context.mounted) Navigator.of(context).maybePop();
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: PlayShuffleRow(
                    enabled: songs.isNotEmpty,
                    onPlay: () => playback.playSongs(songs, 0, shuffle: false),
                    onShuffle: () => playback.shuffleAll(songs),
                  ),
                ),
                ListHeader(
                  count: 'Hold & drag to reorder',
                  sort: SortButton(
                    mode: appStore.sortModeOf(scope, def: SortMode.manual),
                    onChanged: (m) => appStore.setSortMode(scope, m),
                  ),
                ),
                Expanded(
                  child: songs.isEmpty
                      ? EmptyState(
                          icon: Icons.library_music_rounded,
                          title: 'No Songs Yet',
                          subtitle: 'Add songs from your folders to build this playlist.',
                          action: GradientButton(
                            label: 'Add Songs',
                            icon: Icons.add_rounded,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) => SongPickerScreen(playlistId: pl.id),
                              ),
                            ),
                          ),
                        )
                      : ReorderList<Song>(
                          items: songs,
                          keyOf: (s) => s.key,
                          itemExtent: 68,
                          onReordered: (list) => appStore.reorderPlaylistSongs(
                              pl.id, list.map((s) => s.id).toList()),
                          itemBuilder: (context, s, i) => SongTile(
                            song: s,
                            onTap: () => playback.playSongs(songs, i),
                            onMore: () => showSongMenu(context, s, inPlaylist: pl),
                          ),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ============================================================== SONG PICKER

/// Choose songs (grouped by folder) to add to a playlist.
class SongPickerScreen extends StatefulWidget {
  final String playlistId;
  const SongPickerScreen({super.key, required this.playlistId});

  @override
  State<SongPickerScreen> createState() => _SongPickerScreenState();
}

class _SongPickerScreenState extends State<SongPickerScreen> {
  static const String _all = '__all__';
  String? _open; // null = folder list, _all = every song, else folder path
  final Set<int> _selected = <int>{};

  void _toggle(Song s) {
    setState(() {
      if (!_selected.add(s.id)) _selected.remove(s.id);
    });
  }

  void _commit() {
    final pl = appStore.playlistById(widget.playlistId);
    final n = appStore.addToPlaylist(widget.playlistId, _selected);
    Navigator.of(context).maybePop();
    showToast('Added ${plural(n, 'song')} to ${pl?.name ?? 'playlist'}');
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
          builder: (context, _) {
            final pl = appStore.playlistById(widget.playlistId);
            final existing = pl?.songIds.toSet() ?? <int>{};
            return Stack(
              children: [
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                      child: Row(
                        children: [
                          CircleIconButton(
                            icon: _open == null
                                ? Icons.close_rounded
                                : Icons.arrow_back_ios_new_rounded,
                            iconSize: _open == null ? 22 : 19,
                            onTap: () {
                              if (_open == null) {
                                Navigator.of(context).maybePop();
                              } else {
                                setState(() => _open = null);
                              }
                            },
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Text(
                              _open == null
                                  ? 'Add Songs'
                                  : (_open == _all ? 'All Songs' : folderNameOf(_open!)),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.7,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        switchInCurve: Curves.easeOutCubic,
                        transitionBuilder: (child, anim) => FadeTransition(
                          opacity: anim,
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(0.06, 0),
                              end: Offset.zero,
                            ).animate(anim),
                            child: child,
                          ),
                        ),
                        child: _open == null
                            ? _folderList(p)
                            : _songList(p, existing),
                      ),
                    ),
                  ],
                ),
                Positioned(
                  left: 20,
                  right: 20,
                  bottom: 16 + MediaQuery.of(context).padding.bottom,
                  child: AnimatedSlide(
                    duration: const Duration(milliseconds: 360),
                    curve: Curves.easeOutBack,
                    offset: _selected.isEmpty ? const Offset(0, 2.5) : Offset.zero,
                    child: GradientButton(
                      label: 'Add ${plural(_selected.length, 'Song')}',
                      icon: Icons.check_rounded,
                      onTap: _commit,
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _folderList(Palette p) {
    final folders = List<FolderInfo>.of(musicLib.folders)
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    final total = musicLib.visibleSongs.length;
    return ListView(
      key: const ValueKey<String>('folders'),
      padding: const EdgeInsets.only(bottom: 140),
      children: [
        _entryRow(
          p,
          leading: Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: AppColors.primary,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.library_music_rounded, color: Colors.white, size: 27),
          ),
          title: 'All Songs',
          subtitle: plural(total, 'song'),
          onTap: () => setState(() => _open = _all),
        ),
        for (final f in folders)
          _entryRow(
            p,
            leading: const FolderIconBox(),
            title: f.name,
            subtitle: plural(f.songs.length, 'song'),
            badge: f.songs.where((s) => _selected.contains(s.id)).length,
            onTap: () => setState(() => _open = f.path),
          ),
      ],
    );
  }

  Widget _entryRow(
    Palette p, {
    required Widget leading,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    int badge = 0,
  }) {
    return Tappable(
      onTap: onTap,
      pressedScale: 0.975,
      child: Container(
        height: 74,
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            leading,
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(fontSize: 13.5, color: p.subtext)),
                ],
              ),
            ),
            if (badge > 0)
              Container(
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                  gradient: AppColors.primary,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$badge',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
            Icon(Icons.chevron_right_rounded, color: p.subtext),
          ],
        ),
      ),
    );
  }

  Widget _songList(Palette p, Set<int> existing) {
    final open = _open!;
    final songs = List<Song>.of(open == _all
        ? musicLib.visibleSongs
        : musicLib.songsInFolder(open))
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    final selectable = songs.where((s) => !existing.contains(s.id)).toList();
    final allSelected =
        selectable.isNotEmpty && selectable.every((s) => _selected.contains(s.id));
    return Column(
      key: ValueKey<String>('songs:$open'),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 16, 6),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  plural(songs.length, 'song'),
                  style: TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                    color: p.subtext,
                  ),
                ),
              ),
              if (selectable.isNotEmpty)
                Tappable(
                  onTap: () => setState(() {
                    if (allSelected) {
                      for (final s in selectable) {
                        _selected.remove(s.id);
                      }
                    } else {
                      for (final s in selectable) {
                        _selected.add(s.id);
                      }
                    }
                  }),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text(
                      allSelected ? 'Deselect All' : 'Select All',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.accent,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.only(bottom: 140),
            itemCount: songs.length,
            itemExtent: 64,
            itemBuilder: (context, i) {
              final s = songs[i];
              final inList = existing.contains(s.id);
              final sel = _selected.contains(s.id);
              return Tappable(
                onTap: inList ? null : () => _toggle(s),
                pressedScale: 0.98,
                child: Opacity(
                  opacity: inList ? 0.5 : 1,
                  child: Container(
                    height: 64,
                    color: Colors.transparent,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        SongArt(songId: s.id, size: 46, radius: 12),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                s.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 15.5,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                inList ? 'Already in playlist' : s.artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 13, color: p.subtext),
                              ),
                            ],
                          ),
                        ),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 240),
                          curve: Curves.easeOutBack,
                          width: 27,
                          height: 27,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: sel || inList ? AppColors.primary : null,
                            border: sel || inList
                                ? null
                                : Border.all(color: p.subtext, width: 1.6),
                          ),
                          child: AnimatedScale(
                            duration: const Duration(milliseconds: 240),
                            curve: Curves.easeOutBack,
                            scale: sel || inList ? 1 : 0,
                            child: const Icon(Icons.check_rounded, size: 18, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
