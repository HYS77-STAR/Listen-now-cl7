import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';
import 'home.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2400));
  late final AnimationController _loop =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));

  @override
  void initState() {
    super.initState();
    _intro.forward();
    _loop.repeat();
    Future<void>.delayed(const Duration(milliseconds: 3200), _go);
  }

  void _go() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 850),
        pageBuilder: (_, __, ___) => const HomeScreen(),
        transitionsBuilder: (context, anim, secondary, child) {
          final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.07, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _intro.dispose();
    _loop.dispose();
    super.dispose();
  }

  double _seg(double a, double b, [Curve curve = Curves.easeOutCubic]) {
    return Interval(a, b, curve: curve).transform(_intro.value);
  }

  @override
  Widget build(BuildContext context) {
    const title = 'Listen now';
    return Scaffold(
      backgroundColor: const Color(0xFF0A0D1F),
      body: AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[_intro, _loop]),
        builder: (context, _) {
          final t = _loop.value;
          final logoT = Curves.elasticOut.transform(_seg(0.0, 0.55, Curves.linear));
          final logoFade = _seg(0.0, 0.2);
          final glow = 0.5 + 0.5 * math.sin(2 * math.pi * t);

          return Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF060815), Color(0xFF0B1B5E)],
              ),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // drifting glow blobs
                Align(
                  alignment: Alignment(
                    -0.9 + 0.25 * math.sin(2 * math.pi * t),
                    -0.7 + 0.15 * math.cos(2 * math.pi * t),
                  ),
                  child: _blob(320, AppColors.blue1, 0.30),
                ),
                Align(
                  alignment: Alignment(
                    0.9 - 0.25 * math.sin(2 * math.pi * t),
                    0.8 - 0.15 * math.cos(2 * math.pi * t),
                  ),
                  child: _blob(340, AppColors.blue2, 0.22),
                ),
                // expanding rings
                Align(
                  alignment: const Alignment(0, -0.22),
                  child: SizedBox(
                    width: 340,
                    height: 340,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        for (var i = 0; i < 3; i++) _ring((t + i / 3) % 1.0, logoFade),
                      ],
                    ),
                  ),
                ),
                // logo + title
                Align(
                  alignment: const Alignment(0, -0.1),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Opacity(
                        opacity: logoFade.clamp(0.0, 1.0).toDouble(),
                        child: Transform.rotate(
                          angle: -0.18 * (1 - logoT.clamp(0.0, 1.0)),
                          child: Transform.scale(
                            scale: 0.15 + 0.85 * logoT,
                            child: Container(
                              width: 132,
                              height: 132,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(34),
                                boxShadow: [
                                  BoxShadow(
                                    color: alpha(const Color(0xFF7C4DFF), 0.30 + 0.25 * glow),
                                    blurRadius: 40 + 24 * glow,
                                    spreadRadius: 2,
                                  ),
                                  BoxShadow(
                                    color: alpha(AppColors.blue2, 0.18 + 0.12 * glow),
                                    blurRadius: 60,
                                    offset: const Offset(0, 14),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(34),
                                child: Image.asset('assets/icon.png', fit: BoxFit.cover),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 34),
                      ShaderMask(
                        blendMode: BlendMode.srcIn,
                        shaderCallback: (r) => const LinearGradient(
                          colors: [Colors.white, Color(0xFFA9E6FF)],
                        ).createShader(r),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            for (var i = 0; i < title.length; i++)
                              Builder(builder: (context) {
                                final lt = _seg(0.30 + i * 0.04, 0.55 + i * 0.04);
                                return Opacity(
                                  opacity: lt.clamp(0.0, 1.0).toDouble(),
                                  child: Transform.translate(
                                    offset: Offset(0, (1 - lt) * 22),
                                    child: Text(
                                      title[i],
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 42,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ),
                                );
                              }),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Opacity(
                        opacity: _seg(0.72, 1.0).clamp(0.0, 1.0).toDouble(),
                        child: Text(
                          'Your music, offline.',
                          style: TextStyle(
                            fontSize: 15.5,
                            letterSpacing: 0.6,
                            color: Colors.white.withAlpha(165),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // equalizer loader
                Align(
                  alignment: const Alignment(0, 0.82),
                  child: Opacity(
                    opacity: _seg(0.6, 0.9).clamp(0.0, 1.0).toDouble(),
                    child: SizedBox(
                      height: 30,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          for (var i = 0; i < 5; i++) ...[
                            if (i > 0) const SizedBox(width: 5),
                            Container(
                              width: 5,
                              height: 8 +
                                  22 *
                                      (0.5 +
                                          0.5 *
                                              math.sin(2 * math.pi * (t * 2 + i * 0.2))),
                              decoration: BoxDecoration(
                                gradient: AppColors.primary,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _blob(double size, Color color, double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [alpha(color, opacity), alpha(color, 0.0)],
        ),
      ),
    );
  }

  Widget _ring(double p, double fade) {
    final scale = 0.5 + p * 0.9;
    final op = (1 - p) * 0.35 * fade;
    return Transform.scale(
      scale: scale,
      child: Container(
        width: 240,
        height: 240,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: alpha(AppColors.blue2, op.clamp(0.0, 1.0).toDouble()), width: 2),
        ),
      ),
    );
  }
}
