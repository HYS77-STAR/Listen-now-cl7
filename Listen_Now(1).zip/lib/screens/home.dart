import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'player.dart';
import 'settings.dart';
import 'tabs.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final PageController _pc = PageController();
  final TextEditingController _search = TextEditingController();
  final FocusNode _focus = FocusNode();

  int _tab = 0;
  String _query = '';
  bool _focused = false;

  static const List<String> _titles = <String>['Folders', 'Songs', 'Playlists'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _focus.addListener(() {
      if (mounted) setState(() => _focused = _focus.hasFocus);
    });
    musicLib.checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pc.dispose();
    _search.dispose();
    _focus.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (!musicLib.hasPermission) {
        musicLib.checkPermission();
      } else {
        musicLib.refreshIfStale();
      }
    }
  }

  void _goTab(int i) {
    _focus.unfocus();
    _pc.animateToPage(
      i,
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
    );
  }

  void _cancelSearch() {
    _search.clear();
    _focus.unfocus();
    setState(() => _query = '');
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[musicLib, appStore]),
        builder: (context, _) {
          return Stack(
            children: [
              SafeArea(
                bottom: false,
                child: Column(
                  children: [
                    _header(p),
                    _searchBar(p),
                    Expanded(child: _content()),
                  ],
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: IgnorePointer(
                  ignoring: _focused,
                  child: AnimatedSlide(
                    duration: const Duration(milliseconds: 320),
                    curve: Curves.easeOutCubic,
                    offset: _focused ? const Offset(0, 1.3) : Offset.zero,
                    child: _Dock(controller: _pc, tab: _tab, onTab: _goTab),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _header(Palette p) {
    final title = _query.isNotEmpty ? 'Search' : _titles[_tab];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 16, 2),
      child: SizedBox(
        height: 54,
        child: Row(
          children: [
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 340),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.25),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: Align(
                  key: ValueKey<String>(title),
                  alignment: Alignment.centerLeft,
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -1.0,
                    ),
                  ),
                ),
              ),
            ),
            CircleIconButton(
              icon: Icons.settings_rounded,
              onTap: () {
                _focus.unfocus();
                Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchBar(Palette p) {
    final showCancel = _focused || _query.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 46,
              padding: const EdgeInsets.symmetric(horizontal: 13),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Row(
                children: [
                  const GradientIcon(Icons.search_rounded, size: 23),
                  const SizedBox(width: 9),
                  Expanded(
                    child: TextField(
                      controller: _search,
                      focusNode: _focus,
                      textInputAction: TextInputAction.search,
                      onChanged: (v) => setState(() => _query = v.trim()),
                      style: TextStyle(fontSize: 16.5, color: p.text),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        isCollapsed: true,
                        hintText: 'Search songs',
                        hintStyle: TextStyle(fontSize: 16.5, color: p.subtext),
                      ),
                    ),
                  ),
                  if (_search.text.isNotEmpty)
                    Tappable(
                      onTap: () {
                        _search.clear();
                        setState(() => _query = '');
                      },
                      child: Icon(Icons.cancel_rounded, size: 20, color: p.subtext),
                    ),
                ],
              ),
            ),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            child: showCancel
                ? Tappable(
                    onTap: _cancelSearch,
                    child: const Padding(
                      padding: EdgeInsets.only(left: 14),
                      child: Text(
                        'Cancel',
                        style: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.accent,
                        ),
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _content() {
    if (!musicLib.checked) return _loader();
    if (!musicLib.hasPermission) return const _PermissionGate();
    if (musicLib.loading && !musicLib.scanned) return _loader();
    if (_query.isNotEmpty) return _results();
    return PageView(
      controller: _pc,
      onPageChanged: (i) => setState(() => _tab = i),
      children: const <Widget>[FoldersTab(), SongsTab(), PlaylistsTab()],
    );
  }

  Widget _loader() {
    return const Center(
      child: SizedBox(
        width: 30,
        height: 30,
        child: CircularProgressIndicator(strokeWidth: 3, color: AppColors.accent),
      ),
    );
  }

  Widget _results() {
    final q = _query.toLowerCase();
    final results = musicLib.search(_query);
    results.sort((a, b) {
      final sa = a.title.toLowerCase().startsWith(q) ? 0 : 1;
      final sb = b.title.toLowerCase().startsWith(q) ? 0 : 1;
      if (sa != sb) return sa.compareTo(sb);
      return a.title.toLowerCase().compareTo(b.title.toLowerCase());
    });
    if (results.isEmpty) {
      return EmptyState(
        icon: Icons.search_off_rounded,
        title: 'No Results',
        subtitle: 'Nothing matches "$_query". Try a different song, artist or album.',
      );
    }
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              plural(results.length, 'result'),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: context.pal.subtext,
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.only(bottom: 200),
            itemCount: results.length,
            itemExtent: 68,
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemBuilder: (context, i) {
              final s = results[i];
              return SongTile(
                song: s,
                onTap: () {
                  _focus.unfocus();
                  playback.playSongs(results, i);
                },
                onMore: () => showSongMenu(context, s),
              );
            },
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------- permission

class _PermissionGate extends StatefulWidget {
  const _PermissionGate();

  @override
  State<_PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<_PermissionGate> {
  bool _denied = false;

  Future<void> _request() async {
    final ok = await musicLib.requestPermission();
    if (!ok && mounted) setState(() => _denied = true);
  }

  @override
  Widget build(BuildContext context) {
    return EmptyState(
      icon: Icons.library_music_rounded,
      title: 'Allow Music Access',
      subtitle: _denied
          ? 'Access was not granted. Please allow it to see the music stored on your device.'
          : 'Listen now needs to read the audio files on your device to build your library. Everything stays on your phone.',
      action: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GradientButton(label: 'Allow Access', icon: Icons.lock_open_rounded, onTap: _request),
          if (_denied) ...[
            const SizedBox(height: 16),
            Tappable(
              onTap: musicLib.openSettings,
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Text(
                  'Open Settings',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.accent,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------- dock

class _Dock extends StatelessWidget {
  final PageController controller;
  final int tab;
  final ValueChanged<int> onTab;

  const _Dock({required this.controller, required this.tab, required this.onTab});

  static const List<IconData> _icons = <IconData>[
    Icons.folder_rounded,
    Icons.music_note_rounded,
    Icons.queue_music_rounded,
  ];
  static const List<String> _labels = <String>['Folders', 'Songs', 'Playlists'];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final bottom = MediaQuery.of(context).padding.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(14, 0, 14, 8 + (bottom > 0 ? bottom - 4 : 6)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          GlassBox(
            radius: 32,
            child: SizedBox(
              height: 66,
              child: AnimatedBuilder(
                animation: controller,
                builder: (context, _) {
                  var page = tab.toDouble();
                  try {
                    if (controller.hasClients) {
                      final pg = controller.page;
                      if (pg != null) page = pg;
                    }
                  } catch (_) {}
                  return Stack(
                    children: [
                      Align(
                        alignment: Alignment((page - 1.0).clamp(-1.0, 1.0).toDouble(), 0),
                        child: FractionallySizedBox(
                          widthFactor: 1 / 3,
                          heightFactor: 1,
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: AppColors.primary,
                                borderRadius: BorderRadius.circular(26),
                                boxShadow: [
                                  BoxShadow(
                                    color: alpha(AppColors.blue1, 0.40),
                                    blurRadius: 16,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          for (var i = 0; i < 3; i++)
                            Expanded(
                              child: Tappable(
                                onTap: () => onTab(i),
                                pressedScale: 0.88,
                                child: Builder(builder: (context) {
                                  final sel = (1 - (page - i).abs()).clamp(0.0, 1.0).toDouble();
                                  final color = Color.lerp(p.subtext, Colors.white, sel)!;
                                  return Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Transform.scale(
                                        scale: 1 + 0.12 * sel,
                                        child: Icon(_icons[i], size: 25, color: color),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        _labels[i],
                                        style: TextStyle(
                                          fontSize: 11.5,
                                          fontWeight: sel > 0.5 ? FontWeight.w700 : FontWeight.w600,
                                          color: color,
                                        ),
                                      ),
                                    ],
                                  );
                                }),
                              ),
                            ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
