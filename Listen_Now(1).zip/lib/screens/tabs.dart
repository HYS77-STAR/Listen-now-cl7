import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'details.dart';

// ============================================================ shared helpers

class ListHeader extends StatelessWidget {
  final String count;
  final Widget sort;
  final Widget? extra;

  const ListHeader({super.key, required this.count, required this.sort, this.extra});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              count,
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w600,
                color: p.subtext,
              ),
            ),
          ),
          sort,
          if (extra != null) ...[const SizedBox(width: 10), extra!],
        ],
      ),
    );
  }
}

class FolderIconBox extends StatelessWidget {
  final double size;
  const FolderIconBox({super.key, this.size = 52});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: AppColors.primary,
        borderRadius: BorderRadius.circular(size * 0.27),
        boxShadow: [
          BoxShadow(
            color: alpha(AppColors.blue1, 0.28),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Icon(Icons.folder_rounded, color: Colors.white, size: size * 0.54),
    );
  }
}

Widget _entrance(int index, Widget child) {
  if (index > 9) return child;
  return FadeSlideIn(
    delay: Duration(milliseconds: 45 * index),
    dy: 18,
    child: child,
  );
}

// ================================================================ FOLDERS

class FoldersTab extends StatefulWidget {
  const FoldersTab({super.key});

  @override
  State<FoldersTab> createState() => _FoldersTabState();
}

class _FoldersTabState extends State<FoldersTab> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  void _openFolder(FolderInfo f) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => FolderScreen(path: f.path)),
    );
  }

  void _menu(FolderInfo f) {
    showFolderMenu(context, f.path);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final p = context.pal;
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
      builder: (context, _) {
        final folders = appStore.sorted<FolderInfo>(
          scope: 'folders',
          items: musicLib.folders,
          keyOf: (f) => f.path,
          titleOf: (f) => f.name,
          dateOf: (f) => f.newestAdded,
        );
        if (folders.isEmpty) {
          return const EmptyState(
            icon: Icons.folder_off_rounded,
            title: 'No Folders',
            subtitle:
                'No music folders were found. Folders you hide can be restored from Settings → Restore Hidden Files.',
          );
        }
        return Column(
          children: [
            ListHeader(
              count: plural(folders.length, 'Folder'),
              sort: SortButton(
                mode: appStore.sortModeOf('folders'),
                onChanged: (m) => appStore.chooseSort(
                    'folders', m, folders.map((f) => f.path).toList()),
              ),
            ),
            Expanded(
              child: ReorderList<FolderInfo>(
                items: folders,
                keyOf: (f) => f.path,
                itemExtent: 76,
                onReordered: (list) => appStore.setManualOrder(
                    'folders', list.map((f) => f.path).toList()),
                itemBuilder: (context, f, i) {
                  final sub = f.parentLabel.isEmpty
                      ? plural(f.songs.length, 'song')
                      : '${plural(f.songs.length, 'song')} · ${f.parentLabel}';
                  return _entrance(
                    i,
                    Tappable(
                      onTap: () => _openFolder(f),
                      pressedScale: 0.975,
                      child: Container(
                        height: 76,
                        color: Colors.transparent,
                        padding: const EdgeInsets.only(left: 16, right: 4),
                        child: Row(
                          children: [
                            const FolderIconBox(),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    f.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 16.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.2,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    sub,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(fontSize: 13.5, color: p.subtext),
                                  ),
                                ],
                              ),
                            ),
                            Tappable(
                              onTap: () => _menu(f),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Icon(Icons.more_horiz_rounded,
                                    color: p.subtext, size: 22),
                              ),
                            ),
                            Icon(Icons.chevron_right_rounded, color: p.subtext, size: 24),
                            const SizedBox(width: 8),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

/// Menu shared by the folder list and the folder screen.
void showFolderMenu(BuildContext context, String path, {bool popAfterHide = false}) {
  final songs = musicLib.songsInFolder(path);
  final name = folderNameOf(path);
  showActionSheet(
    context,
    header: SheetHeader(
      leading: const FolderIconBox(size: 52),
      title: name,
      subtitle: plural(songs.length, 'song'),
    ),
    actions: [
      SheetAction(
        icon: Icons.play_arrow_rounded,
        label: 'Play',
        onTap: () => playback.playSongs(songs, 0, shuffle: false),
      ),
      SheetAction(
        icon: Icons.shuffle_rounded,
        label: 'Shuffle',
        onTap: () => playback.shuffleAll(songs),
      ),
      SheetAction(
        icon: Icons.library_add_rounded,
        label: 'Add All to Playlist',
        onTap: () => showAddToPlaylistSheet(context, songs.map((s) => s.id).toList()),
      ),
      SheetAction(
        icon: Icons.visibility_off_rounded,
        label: 'Hide Folder',
        destructive: true,
        onTap: () {
          appStore.hideFolder(path);
          if (popAfterHide && Navigator.of(context).canPop()) {
            Navigator.of(context).pop();
          }
          showToast(
            '"$name" hidden',
            actionLabel: 'Undo',
            onAction: () => appStore.restoreFolder(path),
          );
        },
      ),
    ],
  );
}

// ================================================================== SONGS

class SongsTab extends StatefulWidget {
  const SongsTab({super.key});

  @override
  State<SongsTab> createState() => _SongsTabState();
}

class _SongsTabState extends State<SongsTab> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
      builder: (context, _) {
        final songs = appStore.sorted<Song>(
          scope: 'songs',
          items: musicLib.visibleSongs,
          keyOf: (s) => s.key,
          titleOf: (s) => s.title,
          dateOf: (s) => s.dateAdded,
        );
        if (songs.isEmpty) {
          return const EmptyState(
            icon: Icons.music_off_rounded,
            title: 'No Songs',
            subtitle:
                'No music was found on this device. Add some songs and come back, or check your hidden folders in Settings.',
          );
        }
        return Column(
          children: [
            ListHeader(
              count: plural(songs.length, 'Song'),
              sort: SortButton(
                mode: appStore.sortModeOf('songs'),
                onChanged: (m) =>
                    appStore.chooseSort('songs', m, songs.map((s) => s.key).toList()),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: PlayShuffleRow(
                onPlay: () => playback.playSongs(songs, 0, shuffle: false),
                onShuffle: () => playback.shuffleAll(songs),
              ),
            ),
            Expanded(
              child: ReorderList<Song>(
                items: songs,
                keyOf: (s) => s.key,
                itemExtent: 68,
                onReordered: (list) =>
                    appStore.setManualOrder('songs', list.map((s) => s.key).toList()),
                itemBuilder: (context, s, i) {
                  return _entrance(
                    i,
                    SongTile(
                      song: s,
                      onTap: () => playback.playSongs(songs, i),
                      onMore: () => showSongMenu(context, s),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

// =============================================================== PLAYLISTS

Future<void> createPlaylistFlow(BuildContext context) async {
  final name = await showNameDialog(
    context,
    title: 'New Playlist',
    confirmLabel: 'Create',
  );
  if (name == null || !context.mounted) return;
  final pl = appStore.createPlaylist(name);
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => PlaylistScreen(playlistId: pl.id)),
  );
}

Future<void> renamePlaylistFlow(BuildContext context, Playlist pl) async {
  final name = await showNameDialog(
    context,
    title: 'Rename Playlist',
    initial: pl.name,
    confirmLabel: 'Save',
  );
  if (name == null) return;
  appStore.renamePlaylist(pl.id, name);
}

Future<bool> deletePlaylistFlow(BuildContext context, Playlist pl) async {
  final ok = await showConfirm(
    context,
    title: 'Delete Playlist?',
    message: '"${pl.name}" will be deleted. Your songs are not affected.',
    confirmLabel: 'Delete',
    destructive: true,
  );
  if (ok) {
    appStore.deletePlaylist(pl.id);
    showToast('Playlist deleted');
  }
  return ok;
}

class PlaylistCover extends StatelessWidget {
  final List<Song> songs;
  final double size;
  const PlaylistCover({super.key, required this.songs, this.size = 56});

  @override
  Widget build(BuildContext context) {
    if (songs.isNotEmpty) {
      return SongArt(songId: songs.first.id, size: size, radius: size * 0.27);
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: AppColors.primary,
        borderRadius: BorderRadius.circular(size * 0.27),
      ),
      child: Icon(Icons.queue_music_rounded, color: Colors.white, size: size * 0.5),
    );
  }
}

class PlaylistsTab extends StatefulWidget {
  const PlaylistsTab({super.key});

  @override
  State<PlaylistsTab> createState() => _PlaylistsTabState();
}

class _PlaylistsTabState extends State<PlaylistsTab>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  void _menu(Playlist pl) {
    final songs = musicLib.songsForIds(pl.songIds);
    showActionSheet(
      context,
      header: SheetHeader(
        leading: PlaylistCover(songs: songs),
        title: pl.name,
        subtitle: plural(songs.length, 'song'),
      ),
      actions: [
        SheetAction(
          icon: Icons.play_arrow_rounded,
          label: 'Play',
          onTap: () {
            if (songs.isEmpty) {
              showToast('This playlist is empty');
            } else {
              playback.playSongs(songs, 0, shuffle: false);
            }
          },
        ),
        SheetAction(
          icon: Icons.edit_rounded,
          label: 'Rename',
          onTap: () => renamePlaylistFlow(context, pl),
        ),
        SheetAction(
          icon: Icons.delete_outline_rounded,
          label: 'Delete Playlist',
          destructive: true,
          onTap: () => deletePlaylistFlow(context, pl),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final p = context.pal;
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
      builder: (context, _) {
        final lists = appStore.sorted<Playlist>(
          scope: 'playlists',
          items: List<Playlist>.of(appStore.playlists),
          keyOf: (l) => l.id,
          titleOf: (l) => l.name,
          dateOf: (l) => l.createdAt,
        );
        if (lists.isEmpty) {
          return EmptyState(
            icon: Icons.queue_music_rounded,
            title: 'No Playlists Yet',
            subtitle: 'Create a playlist and add songs from any of your folders.',
            action: GradientButton(
              label: 'New Playlist',
              icon: Icons.add_rounded,
              onTap: () => createPlaylistFlow(context),
            ),
          );
        }
        return Column(
          children: [
            ListHeader(
              count: plural(lists.length, 'Playlist'),
              sort: SortButton(
                mode: appStore.sortModeOf('playlists'),
                onChanged: (m) =>
                    appStore.chooseSort('playlists', m, lists.map((l) => l.id).toList()),
              ),
              extra: CircleIconButton(
                icon: Icons.add_rounded,
                filled: true,
                size: 38,
                iconSize: 22,
                onTap: () => createPlaylistFlow(context),
              ),
            ),
            Expanded(
              child: ReorderList<Playlist>(
                items: lists,
                keyOf: (l) => l.id,
                itemExtent: 76,
                onReordered: (list) =>
                    appStore.setManualOrder('playlists', list.map((l) => l.id).toList()),
                itemBuilder: (context, pl, i) {
                  final songs = musicLib.songsForIds(pl.songIds);
                  return _entrance(
                    i,
                    Tappable(
                      pressedScale: 0.975,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => PlaylistScreen(playlistId: pl.id),
                        ),
                      ),
                      child: Container(
                        height: 76,
                        color: Colors.transparent,
                        padding: const EdgeInsets.only(left: 16, right: 4),
                        child: Row(
                          children: [
                            PlaylistCover(songs: songs, size: 54),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    pl.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 16.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.2,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    plural(songs.length, 'song'),
                                    style: TextStyle(fontSize: 13.5, color: p.subtext),
                                  ),
                                ],
                              ),
                            ),
                            Tappable(
                              onTap: () => _menu(pl),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Icon(Icons.more_horiz_rounded,
                                    color: p.subtext, size: 22),
                              ),
                            ),
                            Icon(Icons.chevron_right_rounded, color: p.subtext, size: 24),
                            const SizedBox(width: 8),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
