import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'globals.dart';
import 'models.dart';

/// Scans the device with MediaStore (through a small native bridge) and exposes
/// songs / folders. Hidden folders are filtered out here, nothing on the
/// device is ever touched.
class LibraryService extends ChangeNotifier {
  static const MethodChannel _ch = MethodChannel('hus.player/media');

  List<Song> all = <Song>[];
  final Map<int, Song> _byId = <int, Song>{};

  bool checked = false;
  bool hasPermission = false;
  bool loading = false;
  bool scanned = false;
  DateTime? lastScan;

  String artDir = '';
  Set<int> cachedAlbums = <int>{};

  // ------------------------------------------------------------- permission

  Future<void> checkPermission() async {
    try {
      hasPermission = (await _ch.invokeMethod<bool>('hasPermission')) ?? false;
    } catch (_) {
      hasPermission = false;
    }
    checked = true;
    notifyListeners();
    if (hasPermission) await scan();
  }

  Future<bool> requestPermission() async {
    try {
      hasPermission =
          (await _ch.invokeMethod<bool>('requestPermission')) ?? false;
    } catch (_) {
      hasPermission = false;
    }
    checked = true;
    notifyListeners();
    if (hasPermission) await scan();
    return hasPermission;
  }

  Future<void> openSettings() async {
    try {
      await _ch.invokeMethod<bool>('openAppSettings');
    } catch (_) {}
  }

  // ------------------------------------------------------------------- scan

  Future<void> scan() async {
    if (loading) return;
    loading = true;
    notifyListeners();
    try {
      final raw = await _ch.invokeMethod<List<dynamic>>('querySongs');
      final list = <Song>[];
      for (final e in raw ?? const <dynamic>[]) {
        try {
          final s = Song.fromMap(e as Map<dynamic, dynamic>);
          if (s.id > 0) list.add(s);
        } catch (_) {}
      }
      all = list;
      _byId
        ..clear()
        ..addEntries(list.map((s) => MapEntry(s.id, s)));
    } catch (e) {
      debugPrint('Library scan failed: $e');
    }
    loading = false;
    scanned = true;
    lastScan = DateTime.now();
    notifyListeners();
    _cacheArtwork();
  }

  /// Re-scan when returning to the app (cheap), at most every 20 seconds.
  Future<void> refreshIfStale() async {
    if (!hasPermission || loading) return;
    final last = lastScan;
    if (last == null || DateTime.now().difference(last).inSeconds > 20) {
      await scan();
    }
  }

  // ----------------------------------------------------------------- queries

  Song? byId(int id) => _byId[id];

  List<Song> get visibleSongs =>
      all.where((s) => !appStore.hiddenFolders.contains(s.folder)).toList();

  List<FolderInfo> get folders {
    final map = <String, List<Song>>{};
    for (final s in all) {
      if (appStore.hiddenFolders.contains(s.folder)) continue;
      map.putIfAbsent(s.folder, () => <Song>[]).add(s);
    }
    return map.entries.map((e) => FolderInfo(e.key, e.value)).toList();
  }

  /// Folders the user hid (including ones that no longer contain songs).
  List<FolderInfo> get hiddenFolderInfos {
    final map = <String, List<Song>>{};
    for (final path in appStore.hiddenFolders) {
      map[path] = <Song>[];
    }
    for (final s in all) {
      if (appStore.hiddenFolders.contains(s.folder)) {
        map.putIfAbsent(s.folder, () => <Song>[]).add(s);
      }
    }
    final list = map.entries.map((e) => FolderInfo(e.key, e.value)).toList();
    list.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return list;
  }

  /// Songs for a list of ids, skipping missing ones and hidden folders.
  List<Song> songsForIds(Iterable<int> ids) {
    final out = <Song>[];
    for (final id in ids) {
      final s = _byId[id];
      if (s != null && !appStore.hiddenFolders.contains(s.folder)) out.add(s);
    }
    return out;
  }

  List<Song> songsInFolder(String path) =>
      all.where((s) => s.folder == path).toList();

  /// Songs (never from hidden folders) matching every word of [query].
  List<Song> search(String query) {
    final tokens = query
        .toLowerCase()
        .split(RegExp(r'\s+'))
        .where((t) => t.isNotEmpty)
        .toList();
    if (tokens.isEmpty) return <Song>[];
    final out = <Song>[];
    for (final s in all) {
      if (appStore.hiddenFolders.contains(s.folder)) continue;
      var ok = true;
      for (final t in tokens) {
        if (!s.searchKey.contains(t)) {
          ok = false;
          break;
        }
      }
      if (ok) out.add(s);
    }
    return out;
  }

  // ---------------------------------------------------------------- artwork

  final LinkedHashMap<String, Uint8List?> _artCache =
      LinkedHashMap<String, Uint8List?>();
  final Map<String, Future<Uint8List?>> _pending =
      <String, Future<Uint8List?>>{};

  bool hasArtEntry(int id, int px) => _artCache.containsKey('$id@$px');

  Uint8List? peekArt(int id, int px) => _artCache['$id@$px'];

  Future<Uint8List?> loadArt(int id, int px) {
    final key = '$id@$px';
    if (_artCache.containsKey(key)) return Future<Uint8List?>.value(_artCache[key]);
    final running = _pending[key];
    if (running != null) return running;
    final future = _fetchArt(id, px, key);
    _pending[key] = future;
    return future;
  }

  Future<Uint8List?> _fetchArt(int id, int px, String key) async {
    Uint8List? bytes;
    try {
      bytes = await _ch.invokeMethod<Uint8List>(
          'getArt', <String, dynamic>{'id': id, 'size': px});
    } catch (_) {
      bytes = null;
    }
    _artCache[key] = bytes;
    _pending.remove(key);
    while (_artCache.length > 260) {
      _artCache.remove(_artCache.keys.first);
    }
    return bytes;
  }

  /// Writes one small cover image per album to the cache folder so the
  /// notification / lock screen can show artwork.
  Future<void> _cacheArtwork() async {
    try {
      final seen = <int>{};
      final items = <Map<String, int>>[];
      for (final s in all) {
        if (s.hasAlbum && seen.add(s.albumId)) {
          items.add(<String, int>{'albumId': s.albumId, 'id': s.id});
        }
      }
      if (items.isEmpty) return;
      final res = await _ch.invokeMethod<Map<dynamic, dynamic>>(
          'cacheArt', <String, dynamic>{'items': items});
      if (res == null) return;
      artDir = (res['dir'] ?? '').toString();
      final ids = (res['ids'] as List<dynamic>? ?? const <dynamic>[])
          .map((e) => (e as num).toInt());
      cachedAlbums = ids.toSet();
    } catch (e) {
      debugPrint('Artwork cache failed: $e');
    }
  }

  Uri? artUriFor(Song s) {
    if (artDir.isEmpty || !s.hasAlbum || !cachedAlbums.contains(s.albumId)) {
      return null;
    }
    return Uri.file('$artDir/${s.albumId}.jpg');
  }
}
