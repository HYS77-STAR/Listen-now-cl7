import 'package:flutter/material.dart';

import 'library.dart';
import 'playback.dart';
import 'stats.dart';
import 'store.dart';

final AppStore appStore = AppStore();
final LibraryService musicLib = LibraryService();
final PlaybackService playback = PlaybackService();
final StatsService stats = StatsService();
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

String _two(int n) => n.toString().padLeft(2, '0');

/// 3:05 or 1:03:05
String fmtClock(Duration d) {
  final total = d.inSeconds < 0 ? 0 : d.inSeconds;
  final h = total ~/ 3600;
  final m = (total % 3600) ~/ 60;
  final s = total % 60;
  if (h > 0) return '$h:${_two(m)}:${_two(s)}';
  return '$m:${_two(s)}';
}

/// 45s, 12m, 3h 25m
String fmtListen(int ms) {
  final s = ms ~/ 1000;
  if (s < 60) return '${s}s';
  final m = s ~/ 60;
  if (m < 60) return '${m}m';
  final h = m ~/ 60;
  final rm = m % 60;
  return rm == 0 ? '${h}h' : '${h}h ${rm}m';
}

/// Compact form used above chart bars: 45m, 1.5h
String fmtShort(int ms) {
  final m = ms / 60000.0;
  if (m < 1) return ms <= 0 ? '' : '<1m';
  if (m < 60) return '${m.round()}m';
  final h = m / 60.0;
  return '${h.toStringAsFixed(h >= 10 ? 0 : 1)}h';
}

String plural(int n, String one, [String? many]) =>
    '$n ${n == 1 ? one : (many ?? '${one}s')}';
