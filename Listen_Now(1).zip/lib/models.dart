enum SortMode { dateAdded, alphabetical, manual }

extension SortModeX on SortMode {
  String get label => switch (this) {
        SortMode.dateAdded => 'Date Added',
        SortMode.alphabetical => 'A–Z',
        SortMode.manual => 'Custom',
      };
}

String folderNameOf(String path) {
  final parts = path.split('/').where((e) => e.isNotEmpty).toList();
  if (parts.isEmpty) return 'Storage';
  return parts.last;
}

String _readable(String path) {
  var p = path;
  const internal = '/storage/emulated/0';
  if (p.startsWith(internal)) {
    p = p.substring(internal.length);
  } else if (p.startsWith('/storage/')) {
    final rest = p.substring('/storage/'.length);
    final i = rest.indexOf('/');
    p = i < 0 ? '' : rest.substring(i);
  }
  return p.startsWith('/') ? p.substring(1) : p;
}

class Song {
  final int id;
  final String title;
  final String artist;
  final String album;
  final int albumId;
  final bool hasAlbum;
  final int durationMs;
  final String path;
  final String folder;
  final int dateAdded;
  final String searchKey;

  const Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.hasAlbum,
    required this.durationMs,
    required this.path,
    required this.folder,
    required this.dateAdded,
    required this.searchKey,
  });

  String get key => '$id';
  Uri get uri => Uri.parse('content://media/external/audio/media/$id');
  Duration get duration => Duration(milliseconds: durationMs);

  static int _i(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse('$v') ?? 0;
  }

  static String _s(dynamic v) => v == null ? '' : v.toString();

  factory Song.fromMap(Map<dynamic, dynamic> m) {
    var title = _s(m['title']).trim();
    final display = _s(m['displayName']).trim();
    if (title.isEmpty || title == '<unknown>') {
      final dot = display.lastIndexOf('.');
      title = dot > 0 ? display.substring(0, dot) : display;
    }
    if (title.isEmpty) title = 'Unknown';

    var artist = _s(m['artist']).trim();
    if (artist.isEmpty || artist == '<unknown>') artist = 'Unknown Artist';

    var album = _s(m['album']).trim();
    final hasAlbum = album.isNotEmpty && album != '<unknown>';
    if (!hasAlbum) album = 'Unknown Album';

    final albumId = _i(m['albumId']);
    return Song(
      id: _i(m['id']),
      title: title,
      artist: artist,
      album: album,
      albumId: albumId,
      hasAlbum: hasAlbum && albumId > 0,
      durationMs: _i(m['duration']),
      path: _s(m['path']),
      folder: _s(m['folder']),
      dateAdded: _i(m['added']),
      searchKey: '$title $artist $album'.toLowerCase(),
    );
  }
}

class FolderInfo {
  final String path;
  final List<Song> songs;
  const FolderInfo(this.path, this.songs);

  String get name => folderNameOf(path);

  int get newestAdded {
    var best = 0;
    for (final s in songs) {
      if (s.dateAdded > best) best = s.dateAdded;
    }
    return best;
  }

  int get totalMs => songs.fold<int>(0, (a, s) => a + s.durationMs);

  /// e.g. "Music/Rock" -> "Music"
  String get parentLabel {
    final parts = _readable(path).split('/').where((e) => e.isNotEmpty).toList();
    if (parts.length < 2) return '';
    return parts[parts.length - 2];
  }
}

class Playlist {
  final String id;
  String name;
  List<int> songIds;
  final int createdAt;

  Playlist({
    required this.id,
    required this.name,
    List<int>? songIds,
    required this.createdAt,
  }) : songIds = songIds ?? <int>[];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'songs': songIds,
        'created': createdAt,
      };

  factory Playlist.fromJson(Map<String, dynamic> j) => Playlist(
        id: j['id'] as String,
        name: j['name'] as String,
        songIds: (j['songs'] as List).map((e) => (e as num).toInt()).toList(),
        createdAt: (j['created'] as num).toInt(),
      );
}
