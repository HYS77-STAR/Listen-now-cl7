import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show FontFeature, ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'globals.dart';
import 'models.dart';
import 'theme.dart';

// ============================================================ press feedback

/// Wraps anything to give it a lively "press & bounce back" feel.
class Tappable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double pressedScale;
  final bool haptic;

  const Tappable({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.pressedScale = 0.94,
    this.haptic = true,
  });

  @override
  State<Tappable> createState() => _TappableState();
}

class _TappableState extends State<Tappable> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v && mounted) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null || widget.onLongPress != null;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => _set(true) : null,
      onTapUp: enabled ? (_) => _set(false) : null,
      onTapCancel: enabled ? () => _set(false) : null,
      onTap: widget.onTap == null
          ? null
          : () {
              if (widget.haptic) HapticFeedback.selectionClick();
              widget.onTap!();
            },
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _down ? widget.pressedScale : 1.0,
        duration: Duration(milliseconds: _down ? 90 : 340),
        curve: _down ? Curves.easeOut : Curves.easeOutBack,
        child: widget.child,
      ),
    );
  }
}

// ================================================================ gradients

class GradientIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final Gradient gradient;

  const GradientIcon(
    this.icon, {
    super.key,
    this.size = 22,
    this.gradient = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) =>
          gradient.createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
      child: Icon(icon, size: size, color: Colors.white),
    );
  }
}

class GradientText extends StatelessWidget {
  final String text;
  final TextStyle style;
  final Gradient gradient;

  const GradientText(
    this.text, {
    super.key,
    required this.style,
    this.gradient = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) =>
          gradient.createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
      child: Text(text, style: style.copyWith(color: Colors.white)),
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool compact;

  const GradientButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Tappable(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 16 : 24,
          vertical: compact ? 10 : 15,
        ),
        decoration: BoxDecoration(
          gradient: AppColors.primary,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: alpha(AppColors.blue1, 0.35),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white, size: compact ? 18 : 21),
              const SizedBox(width: 7),
            ],
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: compact ? 14 : 16,
                letterSpacing: -0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  final double iconSize;
  final bool filled;

  const CircleIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.size = 42,
    this.iconSize = 22,
    this.filled = false,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: filled ? AppColors.primary : null,
          color: filled ? null : p.surface,
          boxShadow: filled
              ? [
                  BoxShadow(
                    color: alpha(AppColors.blue1, 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ]
              : null,
        ),
        child: Center(
          child: filled
              ? Icon(icon, size: iconSize, color: Colors.white)
              : GradientIcon(icon, size: iconSize),
        ),
      ),
    );
  }
}

// ================================================================ animation

class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final Duration delay;
  final Duration duration;
  final double dy;

  const FadeSlideIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 520),
    this.dy = 22,
  });

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: widget.duration);
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    if (widget.delay == Duration.zero) {
      _c.forward();
    } else {
      Future<void>.delayed(widget.delay, () {
        if (mounted) _c.forward();
      });
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _a,
      child: widget.child,
      builder: (context, child) {
        return Opacity(
          opacity: _a.value.clamp(0.0, 1.0).toDouble(),
          child: Transform.translate(
            offset: Offset(0, (1 - _a.value) * widget.dy),
            child: child,
          ),
        );
      },
    );
  }
}

class EqualizerBars extends StatefulWidget {
  final bool active;
  final Color color;
  final double height;

  const EqualizerBars({
    super.key,
    required this.active,
    this.color = Colors.white,
    this.height = 18,
  });

  @override
  State<EqualizerBars> createState() => _EqualizerBarsState();
}

class _EqualizerBarsState extends State<EqualizerBars>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));

  @override
  void initState() {
    super.initState();
    if (widget.active) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant EqualizerBars oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !_c.isAnimating) {
      _c.repeat();
    } else if (!widget.active && _c.isAnimating) {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const phases = <double>[0.0, 0.33, 0.66, 0.15];
    return SizedBox(
      height: widget.height,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < phases.length; i++) ...[
                if (i > 0) const SizedBox(width: 2.5),
                Container(
                  width: 3,
                  height: widget.height *
                      (widget.active
                          ? 0.25 +
                              0.75 *
                                  (0.5 +
                                      0.5 *
                                          math.sin(
                                              2 * math.pi * (_c.value + phases[i])))
                          : 0.28),
                  decoration: BoxDecoration(
                    color: widget.color,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

// ================================================================== surfaces

class GlassBox extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry? padding;
  final double blur;

  const GlassBox({
    super.key,
    required this.child,
    this.radius = 28,
    this.padding,
    this.blur = 26,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: p.glass,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: p.glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? action;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(36, 0, 36, 120),
        child: FadeSlideIn(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppColors.soft,
                ),
                child: Center(child: GradientIcon(icon, size: 44)),
              ),
              const SizedBox(height: 22),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, height: 1.35, color: p.subtext),
              ),
              if (action != null) ...[
                const SizedBox(height: 24),
                action!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ==================================================================== artwork

class SongArt extends StatefulWidget {
  final int songId;
  final double size;
  final double radius;
  final int px;
  final bool shadow;

  const SongArt({
    super.key,
    required this.songId,
    this.size = 52,
    this.radius = 12,
    this.px = 200,
    this.shadow = false,
  });

  @override
  State<SongArt> createState() => _SongArtState();
}

class _SongArtState extends State<SongArt> {
  Uint8List? _bytes;
  int _shownId = 0;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant SongArt oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.songId != widget.songId || oldWidget.px != widget.px) {
      _resolve();
    }
  }

  void _resolve() {
    final id = widget.songId;
    final px = widget.px;
    if (id <= 0) {
      _bytes = null;
      _shownId = 0;
      return;
    }
    if (musicLib.hasArtEntry(id, px)) {
      _bytes = musicLib.peekArt(id, px);
      _shownId = id;
      return;
    }
    musicLib.loadArt(id, px).then((b) {
      if (!mounted || widget.songId != id) return;
      setState(() {
        _bytes = b;
        _shownId = id;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final r = BorderRadius.circular(widget.radius);
    final Widget inner = _bytes != null
        ? Image.memory(
            _bytes!,
            key: ValueKey<int>(_shownId),
            width: s,
            height: s,
            fit: BoxFit.cover,
            gaplessPlayback: true,
            cacheWidth: widget.px,
          )
        : Container(
            key: const ValueKey<String>('placeholder'),
            width: s,
            height: s,
            decoration: const BoxDecoration(gradient: AppColors.primary),
            child: Center(
              child: Icon(
                Icons.music_note_rounded,
                size: s * 0.46,
                color: Colors.white.withAlpha(215),
              ),
            ),
          );
    return Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: widget.shadow
            ? [
                BoxShadow(
                  color: Colors.black.withAlpha(90),
                  blurRadius: 30,
                  offset: const Offset(0, 16),
                ),
              ]
            : null,
      ),
      child: ClipRRect(
        borderRadius: r,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 260),
          child: inner,
        ),
      ),
    );
  }
}

// ================================================================== sort menu

class SortButton extends StatelessWidget {
  final SortMode mode;
  final ValueChanged<SortMode> onChanged;

  const SortButton({super.key, required this.mode, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return PopupMenuButton<SortMode>(
      onSelected: (m) {
        HapticFeedback.selectionClick();
        onChanged(m);
      },
      offset: const Offset(0, 46),
      tooltip: 'Sort',
      itemBuilder: (ctx) => [
        for (final m in SortMode.values)
          PopupMenuItem<SortMode>(
            value: m,
            child: Row(
              children: [
                SizedBox(
                  width: 24,
                  child: mode == m
                      ? const GradientIcon(Icons.check_rounded, size: 20)
                      : null,
                ),
                const SizedBox(width: 6),
                Text(
                  m == SortMode.manual ? 'Custom Order' : m.label,
                  style: TextStyle(
                    fontWeight: mode == m ? FontWeight.w700 : FontWeight.w500,
                    fontSize: 15.5,
                    color: p.text,
                  ),
                ),
              ],
            ),
          ),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const GradientIcon(Icons.swap_vert_rounded, size: 19),
            const SizedBox(width: 6),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              child: Text(
                mode.label,
                key: ValueKey<SortMode>(mode),
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: p.text,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================== reorder list

class ReorderList<T> extends StatelessWidget {
  final List<T> items;
  final String Function(T) keyOf;
  final Widget Function(BuildContext, T, int) itemBuilder;
  final ValueChanged<List<T>> onReordered;
  final double itemExtent;
  final EdgeInsets padding;

  const ReorderList({
    super.key,
    required this.items,
    required this.keyOf,
    required this.itemBuilder,
    required this.onReordered,
    required this.itemExtent,
    this.padding = const EdgeInsets.only(bottom: 200),
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ReorderableListView.builder(
      padding: padding,
      itemCount: items.length,
      itemExtent: itemExtent,
      buildDefaultDragHandles: false,
      physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      onReorderStart: (_) => HapticFeedback.mediumImpact(),
      onReorder: (oldIndex, newIndex) {
        if (newIndex > oldIndex) newIndex -= 1;
        final list = List<T>.of(items);
        final moved = list.removeAt(oldIndex);
        list.insert(newIndex, moved);
        HapticFeedback.selectionClick();
        onReordered(list);
      },
      proxyDecorator: (child, index, animation) {
        return AnimatedBuilder(
          animation: animation,
          child: child,
          builder: (context, c) {
            final t = Curves.easeOut.transform(animation.value);
            return Transform.scale(
              scale: 1 + 0.03 * t,
              child: Material(
                color: alpha(p.surface, 0.97),
                elevation: 16 * t,
                shadowColor: Colors.black87,
                borderRadius: BorderRadius.circular(18),
                child: c,
              ),
            );
          },
        );
      },
      itemBuilder: (context, i) {
        final item = items[i];
        return ReorderableDelayedDragStartListener(
          key: ValueKey<String>(keyOf(item)),
          index: i,
          child: itemBuilder(context, item, i),
        );
      },
    );
  }
}

// ================================================================== song tile

class SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback onTap;
  final VoidCallback onMore;

  const SongTile({
    super.key,
    required this.song,
    required this.onTap,
    required this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      pressedScale: 0.975,
      child: Container(
        height: 68,
        padding: const EdgeInsets.only(left: 16, right: 4),
        color: Colors.transparent,
        child: Row(
          children: [
            ValueListenableBuilder<Song?>(
              valueListenable: playback.currentSong,
              builder: (context, cur, _) {
                final isCur = cur?.id == song.id;
                return Stack(
                  children: [
                    SongArt(songId: song.id, size: 52, radius: 13),
                    if (isCur)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withAlpha(120),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: Center(
                            child: StreamBuilder<bool>(
                              stream: playback.player.playingStream,
                              initialData: playback.player.playing,
                              builder: (context, snap) =>
                                  EqualizerBars(active: snap.data ?? false),
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
            const SizedBox(width: 14),
            Expanded(
              child: ValueListenableBuilder<Song?>(
                valueListenable: playback.currentSong,
                builder: (context, cur, _) {
                  final isCur = cur?.id == song.id;
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        song.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.2,
                          color: isCur ? AppColors.accent : p.text,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        song.artist,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 13.5, color: p.subtext),
                      ),
                    ],
                  );
                },
              ),
            ),
            Text(
              fmtClock(song.duration),
              style: TextStyle(
                fontSize: 12.5,
                color: p.subtext,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
            Tappable(
              onTap: onMore,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Icon(Icons.more_horiz_rounded, color: p.subtext, size: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================================================================== toasts

void showToast(String message, {String? actionLabel, VoidCallback? onAction}) {
  final m = messengerKey.currentState;
  if (m == null) return;
  m.clearSnackBars();
  m.showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 14.5,
        ),
      ),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 150),
      backgroundColor: const Color(0xEE2C2C2E),
      elevation: 0,
      duration: const Duration(seconds: 3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      action: actionLabel == null || onAction == null
          ? null
          : SnackBarAction(
              label: actionLabel,
              textColor: AppColors.blue2,
              onPressed: onAction,
            ),
    ),
  );
}

// ==================================================================== sheets

Future<T?> showAppSheet<T>(BuildContext context, {required WidgetBuilder builder}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    elevation: 0,
    sheetAnimationStyle: AnimationStyle(
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
      reverseDuration: const Duration(milliseconds: 260),
      reverseCurve: Curves.easeInCubic,
    ),
    builder: builder,
  );
}

class SheetShell extends StatelessWidget {
  final Widget child;
  final bool tall;

  const SheetShell({super.key, required this.child, this.tall = false});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final mq = MediaQuery.of(context);
    final content = Column(
      mainAxisSize: tall ? MainAxisSize.max : MainAxisSize.min,
      children: [
        const SizedBox(height: 10),
        Container(
          width: 38,
          height: 5,
          decoration: BoxDecoration(
            color: p.divider,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        const SizedBox(height: 8),
        if (tall) Expanded(child: child) else Flexible(child: child),
      ],
    );
    return Padding(
      padding: EdgeInsets.fromLTRB(10, 0, 10, 10 + mq.padding.bottom),
      child: Container(
        constraints: BoxConstraints(maxHeight: mq.size.height * 0.82),
        height: tall ? mq.size.height * 0.72 : null,
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(30),
        ),
        clipBehavior: Clip.antiAlias,
        child: Material(type: MaterialType.transparency, child: content),
      ),
    );
  }
}

class SheetAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  const SheetAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });
}

Future<void> showActionSheet(
  BuildContext context, {
  Widget? header,
  required List<SheetAction> actions,
}) {
  return showAppSheet<void>(
    context,
    builder: (ctx) => SheetShell(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (header != null) header,
            for (final a in actions)
              _ActionRow(
                action: a,
                onPressed: () {
                  Navigator.of(ctx).pop();
                  a.onTap();
                },
              ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    ),
  );
}

class _ActionRow extends StatelessWidget {
  final SheetAction action;
  final VoidCallback onPressed;

  const _ActionRow({required this.action, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = action.destructive ? AppColors.danger : p.text;
    return Tappable(
      onTap: onPressed,
      pressedScale: 0.97,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: action.destructive
                    ? const LinearGradient(
                        colors: [Color(0xFFFF6A5E), Color(0xFFFF3B30)],
                      )
                    : AppColors.primary,
                borderRadius: BorderRadius.circular(11),
              ),
              child: Icon(action.icon, color: Colors.white, size: 21),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Text(
                action.label,
                style: TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w600,
                  color: color,
                  letterSpacing: -0.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SheetHeader extends StatelessWidget {
  final Widget leading;
  final String title;
  final String subtitle;

  const SheetHeader({
    super.key,
    required this.leading,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Row(
        children: [
          leading,
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 13.5, color: p.subtext),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================== dialogs

Future<T?> showAppDialog<T>(BuildContext context, WidgetBuilder builder) {
  return showGeneralDialog<T>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Dismiss',
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 340),
    pageBuilder: (ctx, a1, a2) {
      return Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Center(
          child: Material(type: MaterialType.transparency, child: builder(ctx)),
        ),
      );
    },
    transitionBuilder: (ctx, anim, secondary, child) {
      final curved = CurvedAnimation(
        parent: anim,
        curve: Curves.easeOutBack,
        reverseCurve: Curves.easeInCubic,
      );
      return FadeTransition(
        opacity: anim,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.86, end: 1.0).animate(curved),
          child: child,
        ),
      );
    },
  );
}

class DialogCard extends StatelessWidget {
  final Widget child;
  const DialogCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final w = math.min(MediaQuery.of(context).size.width - 64, 340.0);
    return Container(
      width: w,
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 40, offset: Offset(0, 16)),
        ],
      ),
      child: child,
    );
  }
}

class DialogButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool primary;
  final bool destructive;

  const DialogButton({
    super.key,
    required this.label,
    required this.onTap,
    this.primary = false,
    this.destructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      child: Container(
        height: 48,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: primary && !destructive ? AppColors.primary : null,
          color: primary
              ? (destructive ? AppColors.danger : null)
              : p.surface2,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: primary ? Colors.white : p.text,
          ),
        ),
      ),
    );
  }
}

Future<bool> showConfirm(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  bool destructive = false,
}) async {
  final p = context.pal;
  final result = await showAppDialog<bool>(
    context,
    (ctx) => DialogCard(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, height: 1.35, color: p.subtext),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: DialogButton(
                  label: 'Cancel',
                  onTap: () => Navigator.of(ctx).pop(false),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DialogButton(
                  label: confirmLabel,
                  primary: true,
                  destructive: destructive,
                  onTap: () => Navigator.of(ctx).pop(true),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
  return result ?? false;
}

Future<String?> showNameDialog(
  BuildContext context, {
  required String title,
  String initial = '',
  String confirmLabel = 'Save',
}) {
  return showAppDialog<String>(
    context,
    (ctx) => _NameDialog(title: title, initial: initial, confirmLabel: confirmLabel),
  );
}

class _NameDialog extends StatefulWidget {
  final String title;
  final String initial;
  final String confirmLabel;

  const _NameDialog({
    required this.title,
    required this.initial,
    required this.confirmLabel,
  });

  @override
  State<_NameDialog> createState() => _NameDialogState();
}

class _NameDialogState extends State<_NameDialog> {
  late final TextEditingController _ctrl =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _submit() {
    final v = _ctrl.text.trim();
    if (v.isEmpty) return;
    Navigator.of(context).pop(v);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return DialogCard(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            widget.title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: p.surface2,
              borderRadius: BorderRadius.circular(14),
            ),
            child: TextField(
              controller: _ctrl,
              autofocus: true,
              maxLength: 40,
              textCapitalization: TextCapitalization.sentences,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _submit(),
              style: TextStyle(fontSize: 17, color: p.text),
              decoration: InputDecoration(
                border: InputBorder.none,
                counterText: '',
                hintText: 'Playlist name',
                hintStyle: TextStyle(color: p.subtext),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: DialogButton(
                  label: 'Cancel',
                  onTap: () => Navigator.of(context).pop(),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DialogButton(
                  label: widget.confirmLabel,
                  primary: true,
                  onTap: _submit,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================ song / playlist

void showSongMenu(BuildContext context, Song song, {Playlist? inPlaylist}) {
  showActionSheet(
    context,
    header: SheetHeader(
      leading: SongArt(songId: song.id, size: 52, radius: 13),
      title: song.title,
      subtitle: song.artist,
    ),
    actions: [
      SheetAction(
        icon: Icons.queue_play_next_rounded,
        label: 'Play Next',
        onTap: () {
          playback.playNext(song);
          showToast('Playing next');
        },
      ),
      SheetAction(
        icon: Icons.playlist_add_rounded,
        label: 'Add to Queue',
        onTap: () {
          playback.addToQueue(song);
          showToast('Added to queue');
        },
      ),
      SheetAction(
        icon: Icons.library_add_rounded,
        label: 'Add to Playlist',
        onTap: () => showAddToPlaylistSheet(context, <int>[song.id]),
      ),
      if (inPlaylist != null)
        SheetAction(
          icon: Icons.remove_circle_outline_rounded,
          label: 'Remove from Playlist',
          destructive: true,
          onTap: () {
            appStore.removeFromPlaylist(inPlaylist.id, song.id);
            showToast('Removed from ${inPlaylist.name}');
          },
        ),
    ],
  );
}

Future<void> showAddToPlaylistSheet(BuildContext context, List<int> songIds) {
  return showAppSheet<void>(
    context,
    builder: (ctx) {
      final p = ctx.pal;
      final lists = appStore.playlists;
      return SheetShell(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Add to Playlist',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.4,
                      color: p.text,
                    ),
                  ),
                ),
              ),
              _ActionRow(
                action: SheetAction(
                  icon: Icons.add_rounded,
                  label: 'New Playlist',
                  onTap: () {},
                ),
                onPressed: () async {
                  Navigator.of(ctx).pop();
                  final name = await showNameDialog(
                    context,
                    title: 'New Playlist',
                    confirmLabel: 'Create',
                  );
                  if (name == null) return;
                  final pl = appStore.createPlaylist(name, songIds: songIds);
                  showToast('Added to ${pl.name}');
                },
              ),
              for (final pl in lists)
                _ActionRow(
                  action: SheetAction(
                    icon: Icons.queue_music_rounded,
                    label: pl.name,
                    onTap: () {},
                  ),
                  onPressed: () {
                    Navigator.of(ctx).pop();
                    final n = appStore.addToPlaylist(pl.id, songIds);
                    showToast(n == 0
                        ? 'Already in ${pl.name}'
                        : 'Added ${plural(n, 'song')} to ${pl.name}');
                  },
                ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      );
    },
  );
}

/// Standard "Play / Shuffle" pill pair.
class PlayShuffleRow extends StatelessWidget {
  final VoidCallback onPlay;
  final VoidCallback onShuffle;
  final bool enabled;

  const PlayShuffleRow({
    super.key,
    required this.onPlay,
    required this.onShuffle,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        Expanded(
          child: GradientButton(
            label: 'Play',
            icon: Icons.play_arrow_rounded,
            compact: true,
            onTap: enabled ? onPlay : () {},
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Tappable(
            onTap: enabled ? onShuffle : null,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const GradientIcon(Icons.shuffle_rounded, size: 19),
                  const SizedBox(width: 7),
                  Text(
                    'Shuffle',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: p.text,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
