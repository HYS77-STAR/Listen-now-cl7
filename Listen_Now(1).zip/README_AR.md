# Listen now 🎵

مشغل موسيقى أوفلاين بتصميم iOS حديث (Flutter).

## طريقة تحويله إلى APK عبر GitHub
1. أنشئ مستودعاً جديداً على GitHub.
2. ارفع **كل محتويات** هذا المجلد بعد فك الضغط (بما فيها مجلد `.github` المخفي، ومجلد `android_overrides`).
3. ادخل تبويب **Actions** ثم **Build APK** ثم **Run workflow** (أو سيعمل تلقائياً عند الرفع).
4. بعد انتهاء البناء (حوالي 6-10 دقائق) افتح التشغيلة ونزّل الملف من **Artifacts → Listen-Now-APK**.

> الـ workflow ينشئ مجلد `android` تلقائياً ثم يطبّق الأيقونة والأذونات والكود الأصلي من `android_overrides`.

## تغيير الاسم
- اسم التطبيق تحت الأيقونة: `android_overrides/app/src/main/AndroidManifest.xml` (android:label)
- الاسم في شاشة البداية: `lib/screens/splash.dart` (المتغير title)
