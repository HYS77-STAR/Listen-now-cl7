package com.hus.hus_player

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AudioServiceActivity() {

    private val channelName = "hus.player/media"
    private val permissionRequestCode = 4242
    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingPermissionResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hasPermission" -> result.success(hasAudioPermission())
                    "requestPermission" -> requestAudioPermission(result)
                    "openAppSettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            intent.data = Uri.parse("package:$packageName")
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    "querySongs" -> runAsync(result) { querySongs() }
                    "getArt" -> {
                        val id = (call.argument<Number>("id") ?: 0).toLong()
                        val size = (call.argument<Number>("size") ?: 300).toInt()
                        runAsync(result) { loadArtBytes(id, size) }
                    }
                    "cacheArt" -> {
                        val items = call.argument<List<Map<String, Any>>>("items") ?: emptyList()
                        runAsync(result) { cacheArt(items) }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ---------------------------------------------------------------- helpers

    private fun runAsync(result: MethodChannel.Result, block: () -> Any?) {
        executor.execute {
            try {
                val value = block()
                mainHandler.post { result.success(value) }
            } catch (e: Exception) {
                mainHandler.post { result.error("NATIVE_ERROR", e.message, null) }
            }
        }
    }

    private fun audioPermissionName(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return checkSelfPermission(audioPermissionName()) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission(result: MethodChannel.Result) {
        if (hasAudioPermission()) {
            result.success(true)
            return
        }
        if (Build.VERSION.SDK_INT < 23) {
            result.success(true)
            return
        }
        // Answer any older pending request so it never hangs.
        pendingPermissionResult?.success(false)
        pendingPermissionResult = result
        val perms = ArrayList<String>()
        perms.add(audioPermissionName())
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), permissionRequestCode)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val wanted = audioPermissionName()
            var granted = false
            for (i in permissions.indices) {
                if (permissions[i] == wanted && i < grantResults.size) {
                    granted = grantResults[i] == PackageManager.PERMISSION_GRANTED
                }
            }
            pendingPermissionResult?.success(granted)
            pendingPermissionResult = null
        }
    }

    // ------------------------------------------------------------- song query

    private fun querySongs(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = ArrayList<String>()
        projection.add(MediaStore.Audio.Media._ID)
        projection.add(MediaStore.Audio.Media.TITLE)
        projection.add(MediaStore.Audio.Media.ARTIST)
        projection.add(MediaStore.Audio.Media.ALBUM)
        projection.add(MediaStore.Audio.Media.ALBUM_ID)
        projection.add(MediaStore.Audio.Media.DURATION)
        projection.add(MediaStore.Audio.Media.DATA)
        projection.add(MediaStore.Audio.Media.DATE_ADDED)
        projection.add(MediaStore.Audio.Media.DISPLAY_NAME)
        if (Build.VERSION.SDK_INT >= 29) projection.add(MediaStore.Audio.Media.RELATIVE_PATH)

        val selection =
            "${MediaStore.Audio.Media.DURATION} >= 5000 AND " +
                "(${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.DURATION} >= 60000)"

        val cursor = contentResolver.query(
            collection,
            projection.toTypedArray(),
            selection,
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        ) ?: return out

        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iDisplay = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iRelative =
                if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH) else -1

            while (c.moveToNext()) {
                val data = if (c.isNull(iData)) "" else c.getString(iData) ?: ""
                var folder = ""
                if (data.isNotEmpty()) {
                    folder = File(data).parent ?: ""
                }
                if (folder.isEmpty() && iRelative >= 0 && !c.isNull(iRelative)) {
                    val rel = (c.getString(iRelative) ?: "").trimEnd('/')
                    folder = "/storage/emulated/0/$rel"
                }
                if (folder.isEmpty()) folder = "/storage/emulated/0"

                val map = HashMap<String, Any?>()
                map["id"] = c.getLong(iId)
                map["title"] = if (c.isNull(iTitle)) "" else c.getString(iTitle)
                map["artist"] = if (c.isNull(iArtist)) "" else c.getString(iArtist)
                map["album"] = if (c.isNull(iAlbum)) "" else c.getString(iAlbum)
                map["albumId"] = c.getLong(iAlbumId)
                map["duration"] = c.getLong(iDuration)
                map["path"] = data
                map["folder"] = folder
                map["added"] = c.getLong(iAdded)
                map["displayName"] = if (c.isNull(iDisplay)) "" else c.getString(iDisplay)
                out.add(map)
            }
        }
        return out
    }

    // ---------------------------------------------------------------- artwork

    private fun songUri(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    private fun loadBitmap(id: Long, size: Int): Bitmap? {
        val uri = songUri(id)
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return contentResolver.loadThumbnail(uri, Size(size, size), null)
            } catch (e: Exception) {
                // fall through to the metadata retriever
            }
        }
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val bytes = retriever.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: Exception) {
            return null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun loadArtBytes(id: Long, size: Int): ByteArray? {
        val bmp = loadBitmap(id, size) ?: return null
        val stream = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, stream)
        return stream.toByteArray()
    }

    private fun cacheArt(items: List<Map<String, Any>>): Map<String, Any> {
        val dir = File(cacheDir, "art")
        if (!dir.exists()) dir.mkdirs()
        val done = ArrayList<Long>()
        for (item in items) {
            val albumId = (item["albumId"] as? Number)?.toLong() ?: continue
            val songId = (item["id"] as? Number)?.toLong() ?: continue
            val file = File(dir, "$albumId.jpg")
            if (file.exists() && file.length() > 0) {
                done.add(albumId)
                continue
            }
            try {
                val bmp = loadBitmap(songId, 384) ?: continue
                FileOutputStream(file).use { out ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
                done.add(albumId)
            } catch (e: Exception) {
                // skip this album
            }
        }
        val res = HashMap<String, Any>()
        res["dir"] = dir.absolutePath
        res["ids"] = done
        return res
    }
}
